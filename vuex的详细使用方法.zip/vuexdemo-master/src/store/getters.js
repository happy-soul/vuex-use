// 获取最终的状态信息
export const resturantName = state => state.resturantName